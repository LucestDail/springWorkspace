package osh;

import org.springframework.stereotype.Component;

@Component
public class MariadbArticleDao implements ArticleDao{

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("mariadb에 저장합니다");
	}

}
