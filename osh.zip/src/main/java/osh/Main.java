package osh;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		final String ctxconfig = "classpath:applicationContext.xml";
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext(ctxconfig);
		WriteArticleService articleService = ctx.getBean("writeArticleService", WriteArticleService.class);
		articleService.write(new Article());
	}
}
