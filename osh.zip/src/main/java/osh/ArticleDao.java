package osh;

public interface ArticleDao {
	void insert();
}
