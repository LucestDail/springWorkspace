package osh;
public interface WriteArticleService {
	void write(Article article);
}
